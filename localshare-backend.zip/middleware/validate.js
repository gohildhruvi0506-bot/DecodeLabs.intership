// ============================================================
//  middleware/validate.js
//  Input validation helpers — "The Gatekeeper Rule"
//  Never trust the client. Validate everything.
// ============================================================

// ── Validate peer registration body ──────────────────────────
function validatePeer(req, res, next) {
  const { name, ip } = req.body;
  const errors = [];

  // Syntactic validation: are required fields present?
  if (!name || typeof name !== 'string') {
    errors.push('name is required and must be a string');
  } else if (name.trim().length < 2 || name.trim().length > 50) {
    errors.push('name must be between 2 and 50 characters');
  }

  if (!ip || typeof ip !== 'string') {
    errors.push('ip is required and must be a string');
  } else {
    // Semantic validation: is the IP actually valid?
    const ipRegex =
      /^(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)\.(25[0-5]|2[0-4]\d|[01]?\d\d?)$/;
    if (!ipRegex.test(ip.trim())) {
      errors.push('ip must be a valid IPv4 address (e.g. 192.168.1.10)');
    }
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      error  : 'Validation failed',
      details: errors
    });
  }

  // Sanitise before passing on
  req.body.name = name.trim();
  req.body.ip   = ip.trim();
  next();
}

// ── Validate transfer initiation body ────────────────────────
function validateTransfer(req, res, next) {
  const { fileId, targetPeer } = req.body;
  const errors = [];

  if (!fileId || typeof fileId !== 'string') {
    errors.push('fileId is required and must be a string');
  }

  if (!targetPeer || typeof targetPeer !== 'string') {
    errors.push('targetPeer is required and must be a string');
  } else if (targetPeer.trim().length < 2) {
    errors.push('targetPeer must be at least 2 characters');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      error  : 'Validation failed',
      details: errors
    });
  }

  req.body.fileId     = fileId.trim();
  req.body.targetPeer = targetPeer.trim();
  next();
}

module.exports = { validatePeer, validateTransfer };

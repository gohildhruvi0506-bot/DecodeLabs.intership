# LocalShare — Backend API
## DecodeLabs Industrial Training · Project 2: Backend API Development

---

## 📁 Project Structure

```
localshare-backend/
│
├── server.js                 ← Entry point · Express app setup
│
├── routes/
│   ├── peers.js              ← GET & POST /api/peers
│   ├── files.js              ← GET & POST /api/files
│   └── transfers.js          ← GET, POST & PUT /api/transfers
│
├── middleware/
│   └── validate.js           ← Input validation (The Gatekeeper Rule)
│
├── public/
│   └── index.html            ← Your frontend (served by Express)
│
├── uploads/                  ← Uploaded files saved here
├── package.json
└── README.md
```

---

## 🚀 How to Run

### 1. Install dependencies
```bash
npm install
```

### 2. Start the server
```bash
node server.js
# or for auto-reload during development:
npm run dev
```

### 3. Open the app
```
http://localhost:3000
```

---

## 📡 API Endpoints

### Health Check
| Method | Endpoint       | Description        |
|--------|----------------|--------------------|
| GET    | /api/health    | Check server is up |

---

### Peers (Nearby Devices)
| Method | Endpoint         | Description             |
|--------|------------------|-------------------------|
| GET    | /api/peers       | Get all online peers    |
| GET    | /api/peers/:id   | Get one peer by ID      |
| POST   | /api/peers       | Register a new peer     |
| DELETE | /api/peers/:id   | Mark a peer as offline  |

**POST /api/peers — Request Body:**
```json
{
  "name": "My Laptop",
  "ip": "192.168.1.50"
}
```

**Validation Rules:**
- `name`: required, string, 2–50 characters
- `ip`: required, valid IPv4 address (e.g. 192.168.1.10)

---

### Files (Shared Media)
| Method | Endpoint             | Description                      |
|--------|----------------------|----------------------------------|
| GET    | /api/files           | List all shared files            |
| GET    | /api/files?category= | Filter by video/image/audio/etc. |
| GET    | /api/files/:id       | Get one file's metadata          |
| POST   | /api/files/upload    | Upload a real file (multipart)   |

**POST /api/files/upload — Form Data:**
- Field `file`: the file to upload
- Field `uploadedBy` (optional): sender's name

**Allowed file types:** images, videos, audio, PDF, ZIP, RAR, Word docs, plain text

---

### Transfers (Active/Completed)
| Method | Endpoint               | Description                    |
|--------|------------------------|--------------------------------|
| GET    | /api/transfers         | List all transfers             |
| GET    | /api/transfers?status= | Filter by active/complete/etc. |
| GET    | /api/transfers/:id     | Get one transfer's status      |
| POST   | /api/transfers         | Initiate a new transfer        |
| PUT    | /api/transfers/:id     | Update progress / status       |

**POST /api/transfers — Request Body:**
```json
{
  "fileId": "file-001",
  "targetPeer": "Rohan's Laptop",
  "direction": "outgoing"
}
```

**PUT /api/transfers/:id — Request Body:**
```json
{
  "progress": 75,
  "status": "active"
}
```

---

## 📊 HTTP Status Codes Used

| Code | Meaning         | When used                             |
|------|-----------------|---------------------------------------|
| 200  | OK              | Successful GET / PUT                  |
| 201  | Created         | Successful POST (new resource made)   |
| 400  | Bad Request     | Validation failed, missing fields     |
| 404  | Not Found       | Peer / File / Transfer ID not found   |
| 409  | Conflict        | Duplicate peer IP or active transfer  |
| 500  | Internal Error  | Unexpected server crash               |

---

## ✅ Project 2 Requirements Checklist

- [x] **GET endpoints** — `/api/peers`, `/api/files`, `/api/transfers`
- [x] **POST endpoints** — register peer, upload file, initiate transfer
- [x] **Handle user input** — all POST bodies parsed and processed
- [x] **Handle responses** — consistent JSON `{ success, data, error }` format
- [x] **Validate basic data** — type checks, length, IP regex, range checks
- [x] **Correct HTTP status codes** — 200, 201, 400, 404, 409, 500
- [x] **RESTful naming** — nouns not verbs (`/files` not `/getFiles`)
- [x] **Error handling** — global 404 + 500 middleware
- [x] **File upload** — multipart via Multer with type/size validation
- [x] **Frontend integration** — index.html calls the API on every action

---

## 🧪 Test Your API (without a browser)

Install a REST client like **Thunder Client** (VS Code extension) or use `curl`:

```bash
# Check health
curl http://localhost:3000/api/health

# Get all peers
curl http://localhost:3000/api/peers

# Register a new peer
curl -X POST http://localhost:3000/api/peers \
  -H "Content-Type: application/json" \
  -d '{"name":"My Phone","ip":"192.168.1.99"}'

# Upload a file
curl -X POST http://localhost:3000/api/files/upload \
  -F "file=@/path/to/yourfile.pdf" \
  -F "uploadedBy=You"

# Get all transfers
curl http://localhost:3000/api/transfers
```

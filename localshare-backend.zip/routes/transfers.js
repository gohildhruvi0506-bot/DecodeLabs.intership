// ============================================================
//  routes/transfers.js
//  GET  /api/transfers        → list all transfers
//  POST /api/transfers        → initiate a new transfer
//  GET  /api/transfers/:id    → get transfer status
//  PUT  /api/transfers/:id    → update transfer progress
// ============================================================

const express            = require('express');
const { v4: uuidv4 }     = require('uuid');
const { validateTransfer } = require('../middleware/validate');

const router = express.Router();

// ── In-memory transfer store ──────────────────────────────────
// Pre-seeded with the demo transfers shown in your Active Transfers section
let transfers = [
  {
    id         : 'xfr-001',
    fileName   : 'assets_bundle.zip',
    fileId     : 'file-005',
    targetPeer : "Rohan's Laptop",
    direction  : 'outgoing',
    sizeMB     : 120,
    progress   : 100,
    status     : 'complete',
    startedAt  : new Date(Date.now() - 60000).toISOString(),
    completedAt: new Date().toISOString()
  },
  {
    id         : 'xfr-002',
    fileName   : 'demo_reel.mp4',
    fileId     : 'file-001',
    targetPeer : "Ananya's Mac",
    direction  : 'incoming',
    sizeMB     : 48,
    progress   : 100,
    status     : 'complete',
    startedAt  : new Date(Date.now() - 120000).toISOString(),
    completedAt: new Date().toISOString()
  }
];

// ── GET /api/transfers ────────────────────────────────────────
// Returns all transfers; supports ?status= filter
router.get('/', (req, res) => {
  let result = [...transfers];

  // Optional filter: GET /api/transfers?status=active
  const { status } = req.query;
  if (status) {
    result = result.filter(t => t.status === status);
  }

  res.status(200).json({
    success  : true,
    count    : result.length,
    transfers: result
  });
});

// ── GET /api/transfers/:id ────────────────────────────────────
// Returns a single transfer's current status
router.get('/:id', (req, res) => {
  const transfer = transfers.find(t => t.id === req.params.id);

  if (!transfer) {
    return res.status(404).json({
      success: false,
      error  : `Transfer with id "${req.params.id}" not found`
    });
  }

  res.status(200).json({ success: true, transfer });
});

// ── POST /api/transfers ───────────────────────────────────────
// Initiate a new file transfer
// Body: { fileId: string, targetPeer: string, direction?: "incoming"|"outgoing" }
router.post('/', validateTransfer, (req, res) => {
  const { fileId, targetPeer, direction = 'outgoing' } = req.body;

  // Semantic validation: direction must be a known value
  if (!['incoming', 'outgoing'].includes(direction)) {
    return res.status(400).json({
      success: false,
      error  : 'direction must be either "incoming" or "outgoing"'
    });
  }

  // Check for a duplicate active transfer of the same file to the same peer
  const duplicate = transfers.find(
    t => t.fileId === fileId && t.targetPeer === targetPeer && t.status === 'active'
  );

  if (duplicate) {
    return res.status(409).json({
      success : false,
      error   : 'A transfer for this file to this peer is already active',
      existing: duplicate
    });
  }

  const newTransfer = {
    id        : uuidv4(),
    fileId,
    targetPeer,
    direction,
    fileName  : `file-${fileId}`,   // Would be resolved from files store in production
    sizeMB    : 0,
    progress  : 0,
    status    : 'active',
    startedAt : new Date().toISOString(),
    completedAt: null
  };

  transfers.push(newTransfer);

  // 201 Created
  res.status(201).json({
    success  : true,
    message  : `Transfer to "${targetPeer}" initiated`,
    transfer : newTransfer
  });
});

// ── PUT /api/transfers/:id ────────────────────────────────────
// Update progress of a transfer (called periodically by the client)
// Body: { progress: number (0-100), status?: string }
router.put('/:id', (req, res) => {
  const transfer = transfers.find(t => t.id === req.params.id);

  if (!transfer) {
    return res.status(404).json({
      success: false,
      error  : `Transfer with id "${req.params.id}" not found`
    });
  }

  const { progress, status } = req.body;

  // Validate progress value
  if (progress !== undefined) {
    const p = Number(progress);
    if (isNaN(p) || p < 0 || p > 100) {
      return res.status(400).json({
        success: false,
        error  : 'progress must be a number between 0 and 100'
      });
    }
    transfer.progress = p;
  }

  // Update status if provided
  const VALID_STATUSES = ['active', 'paused', 'complete', 'failed'];
  if (status !== undefined) {
    if (!VALID_STATUSES.includes(status)) {
      return res.status(400).json({
        success: false,
        error  : `status must be one of: ${VALID_STATUSES.join(', ')}`
      });
    }
    transfer.status = status;
    if (status === 'complete') transfer.completedAt = new Date().toISOString();
  }

  // Auto-complete when progress hits 100
  if (transfer.progress === 100 && transfer.status !== 'failed') {
    transfer.status      = 'complete';
    transfer.completedAt = transfer.completedAt || new Date().toISOString();
  }

  res.status(200).json({
    success : true,
    message : 'Transfer updated',
    transfer
  });
});

module.exports = router;

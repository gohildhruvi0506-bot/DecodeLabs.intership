// ============================================================
//  routes/files.js
//  GET  /api/files        → list all shared files
//  POST /api/files/upload → upload a file (multipart/form-data)
//  GET  /api/files/:id    → get single file metadata
// ============================================================

const express        = require('express');
const multer         = require('multer');
const path           = require('path');
const fs             = require('fs');
const { v4: uuidv4 } = require('uuid');

const router = express.Router();

// ── Multer storage config ─────────────────────────────────────
// Determines where and how uploaded files are saved
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../uploads'));
  },
  filename: (req, file, cb) => {
    // Preserve original name but add timestamp to avoid collisions
    const ext      = path.extname(file.originalname);
    const baseName = path.basename(file.originalname, ext).replace(/\s+/g, '_');
    cb(null, `${baseName}-${Date.now()}${ext}`);
  }
});

// ── File type validation (Gatekeeper Rule) ────────────────────
const ALLOWED_TYPES = [
  'image/jpeg', 'image/png', 'image/gif', 'image/webp',
  'video/mp4', 'video/quicktime', 'video/x-msvideo',
  'audio/mpeg', 'audio/wav', 'audio/ogg',
  'application/pdf',
  'application/zip', 'application/x-zip-compressed',
  'application/x-rar-compressed',
  'text/plain', 'text/csv',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
];

const fileFilter = (req, file, cb) => {
  if (ALLOWED_TYPES.includes(file.mimetype)) {
    cb(null, true);   // Accept file
  } else {
    // Reject with a clear error — don't silently drop
    cb(new Error(`File type "${file.mimetype}" is not allowed`), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 250 * 1024 * 1024  // 250 MB max (matches your frontend UI text)
  }
});

// ── In-memory file registry ───────────────────────────────────
// Pre-seeded with the demo files shown in your media grid
let sharedFiles = [
  {
    id        : 'file-001',
    name      : 'demo_reel.mp4',
    type      : 'video/mp4',
    category  : 'video',
    sizeMB    : 48,
    uploadedBy: 'Ananya\'s Mac',
    uploadedAt: new Date().toISOString(),
    url       : null   // null = demo file, not actually on disk
  },
  {
    id        : 'file-002',
    name      : 'wireframe_v2.png',
    type      : 'image/png',
    category  : 'image',
    sizeMB    : 1.2,
    uploadedBy: 'You',
    uploadedAt: new Date().toISOString(),
    url       : null
  },
  {
    id        : 'file-003',
    name      : 'bgm_track.mp3',
    type      : 'audio/mpeg',
    category  : 'audio',
    sizeMB    : 4.8,
    uploadedBy: 'Rohan\'s Laptop',
    uploadedAt: new Date().toISOString(),
    url       : null
  },
  {
    id        : 'file-004',
    name      : 'project_brief.pdf',
    type      : 'application/pdf',
    category  : 'document',
    sizeMB    : 0.9,
    uploadedBy: 'You',
    uploadedAt: new Date().toISOString(),
    url       : null
  },
  {
    id        : 'file-005',
    name      : 'assets_bundle.zip',
    type      : 'application/zip',
    category  : 'archive',
    sizeMB    : 120,
    uploadedBy: 'You',
    uploadedAt: new Date().toISOString(),
    url       : null
  }
];

// ── Helper: derive category from MIME type ─────────────────────
function getCategory(mimeType) {
  if (mimeType.startsWith('image/'))     return 'image';
  if (mimeType.startsWith('video/'))     return 'video';
  if (mimeType.startsWith('audio/'))     return 'audio';
  if (mimeType === 'application/pdf')    return 'document';
  if (mimeType.includes('zip') || mimeType.includes('rar')) return 'archive';
  return 'other';
}

// ── GET /api/files ────────────────────────────────────────────
// Returns all shared files; supports ?category= filter
router.get('/', (req, res) => {
  let result = [...sharedFiles];

  // Optional filter: GET /api/files?category=video
  const { category } = req.query;
  if (category) {
    result = result.filter(f => f.category === category);
  }

  res.status(200).json({
    success: true,
    count  : result.length,
    files  : result
  });
});

// ── GET /api/files/:id ────────────────────────────────────────
// Returns metadata for a single file
router.get('/:id', (req, res) => {
  const file = sharedFiles.find(f => f.id === req.params.id);

  if (!file) {
    return res.status(404).json({
      success: false,
      error  : `File with id "${req.params.id}" not found`
    });
  }

  res.status(200).json({ success: true, file });
});

// ── POST /api/files/upload ────────────────────────────────────
// Accepts a real file upload (multipart/form-data)
// Field name: "file"   Optional field: "uploadedBy"
router.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({
      success: false,
      error  : 'No file was uploaded. Use field name "file".'
    });
  }

  const sizeMB = parseFloat((req.file.size / (1024 * 1024)).toFixed(2));

  const newFile = {
    id        : uuidv4(),
    name      : req.file.originalname,
    storedAs  : req.file.filename,
    type      : req.file.mimetype,
    category  : getCategory(req.file.mimetype),
    sizeMB,
    uploadedBy: req.body.uploadedBy || 'Unknown',
    uploadedAt: new Date().toISOString(),
    url       : `/uploads/${req.file.filename}`
  };

  sharedFiles.push(newFile);

  // 201 Created
  res.status(201).json({
    success : true,
    message : `"${newFile.name}" uploaded successfully`,
    file    : newFile
  });
});

// ── Multer error handler ──────────────────────────────────────
router.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        success: false,
        error  : 'File too large. Maximum allowed size is 250 MB.'
      });
    }
    return res.status(400).json({ success: false, error: err.message });
  }
  if (err) {
    return res.status(400).json({ success: false, error: err.message });
  }
  next();
});

module.exports = router;

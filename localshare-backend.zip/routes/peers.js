// ============================================================
//  routes/peers.js
//  GET  /api/peers        → list all nearby peers
//  POST /api/peers        → register a new peer
//  GET  /api/peers/:id    → get single peer info
// ============================================================

const express        = require('express');
const { v4: uuidv4 } = require('uuid');
const { validatePeer } = require('../middleware/validate');

const router = express.Router();

// In-memory store (acts as our simple "database" for Project 2)
// Pre-seeded with the 3 peers shown in your frontend UI
let peers = [
  {
    id       : 'peer-001',
    name     : "Ananya's Mac",
    ip       : '192.168.1.12',
    speed    : '2.4 MB/s',
    initials : 'AN',
    online   : true,
    joinedAt : new Date().toISOString()
  },
  {
    id       : 'peer-002',
    name     : "Rohan's Laptop",
    ip       : '192.168.1.18',
    speed    : '5.1 MB/s',
    initials : 'RK',
    online   : true,
    joinedAt : new Date().toISOString()
  },
  {
    id       : 'peer-003',
    name     : "Priya's Phone",
    ip       : '192.168.1.25',
    speed    : '1.8 MB/s',
    initials : 'PS',
    online   : true,
    joinedAt : new Date().toISOString()
  }
];

// ── GET /api/peers ────────────────────────────────────────────
// Returns list of all currently online peers
router.get('/', (req, res) => {
  const onlinePeers = peers.filter(p => p.online);

  res.status(200).json({
    success: true,
    count  : onlinePeers.length,
    peers  : onlinePeers
  });
});

// ── GET /api/peers/:id ────────────────────────────────────────
// Returns a single peer by ID
router.get('/:id', (req, res) => {
  const peer = peers.find(p => p.id === req.params.id);

  if (!peer) {
    return res.status(404).json({
      success: false,
      error  : `Peer with id "${req.params.id}" not found`
    });
  }

  res.status(200).json({
    success: true,
    peer
  });
});

// ── POST /api/peers ───────────────────────────────────────────
// Register a new peer on the network
// Body: { name: string, ip: string }
router.post('/', validatePeer, (req, res) => {
  const { name, ip } = req.body;

  // Semantic check: prevent duplicate IPs
  const duplicate = peers.find(p => p.ip === ip);
  if (duplicate) {
    return res.status(409).json({
      success: false,
      error  : `A peer with IP ${ip} is already registered`,
      existing: duplicate
    });
  }

  // Build initials from name (e.g. "Rohan Kumar" → "RK")
  const initials = name
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const newPeer = {
    id      : uuidv4(),
    name,
    ip,
    speed   : '-- MB/s',
    initials,
    online  : true,
    joinedAt: new Date().toISOString()
  };

  peers.push(newPeer);

  // 201 Created — resource was successfully created
  res.status(201).json({
    success : true,
    message : `Peer "${name}" registered successfully`,
    peer    : newPeer
  });
});

// ── DELETE /api/peers/:id ─────────────────────────────────────
// Mark a peer as offline (soft delete)
router.delete('/:id', (req, res) => {
  const peer = peers.find(p => p.id === req.params.id);

  if (!peer) {
    return res.status(404).json({
      success: false,
      error  : `Peer with id "${req.params.id}" not found`
    });
  }

  peer.online = false;

  // 204 No Content is standard for successful DELETE with no body needed,
  // but we return 200 with a message for better DX (Developer Experience)
  res.status(200).json({
    success: true,
    message: `Peer "${peer.name}" has gone offline`
  });
});

module.exports = router;

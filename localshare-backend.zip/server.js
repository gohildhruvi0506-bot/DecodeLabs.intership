// ============================================================
//  LocalShare Backend — server.js
//  DecodeLabs Industrial Training · Project 2
//  Backend API Development
// ============================================================

const express = require('express');
const cors    = require('cors');
const path    = require('path');
const fs      = require('fs');

// Route imports
const peersRouter     = require('./routes/peers');
const filesRouter     = require('./routes/files');
const transfersRouter = require('./routes/transfers');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ────────────────────────────────────────────────
app.use(cors());                          // Allow frontend requests
app.use(express.json());                  // Parse JSON bodies
app.use(express.urlencoded({ extended: true }));

// Serve uploaded files as static assets
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);
app.use('/uploads', express.static(uploadsDir));

// Serve the frontend HTML
app.use(express.static(path.join(__dirname, 'public')));

// ── API Routes ────────────────────────────────────────────────
app.use('/api/peers',     peersRouter);
app.use('/api/files',     filesRouter);
app.use('/api/transfers', transfersRouter);

// ── Health check ──────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status : 'ok',
    app    : 'LocalShare API',
    version: '1.0.0',
    time   : new Date().toISOString()
  });
});

// ── 404 handler ───────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error  : 'Route not found',
    path   : req.originalUrl
  });
});

// ── Global error handler ──────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[ERROR]', err.message);
  res.status(500).json({
    success: false,
    error  : 'Internal server error',
    message: err.message
  });
});

// ── Start server ──────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀  LocalShare API running at http://localhost:${PORT}`);
  console.log(`📡  Health check → http://localhost:${PORT}/api/health\n`);
});

module.exports = app;
